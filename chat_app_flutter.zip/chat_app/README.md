# 📱 চ্যাট অ্যাপ — Flutter WebView

## ✅ ধাপ ১: Flutter ইনস্টল করুন (একবারই করতে হবে)

### Windows-এ:
1. https://docs.flutter.dev/get-started/install/windows থেকে Flutter SDK ডাউনলোড করুন
2. ZIP খুলে `C:\flutter` ফোল্ডারে রাখুন
3. Environment Variable-এ `C:\flutter\bin` যুক্ত করুন
4. Command Prompt-এ টাইপ করুন: `flutter doctor`

### Android Studio ইনস্টল:
1. https://developer.android.com/studio থেকে ডাউনলোড করুন
2. ইনস্টল করুন → SDK Tools → Android SDK ইনস্টল করুন

---

## ✅ ধাপ ২: প্রজেক্ট চালু করুন

```bash
# এই ফোল্ডারে যান
cd chat_app

# Dependencies ইনস্টল করুন
flutter pub get

# অ্যাপ রান করুন (ফোন কানেক্ট করুন প্রথমে)
flutter run
```

---

## ✅ ধাপ ৩: APK বানান (ফোনে ইনস্টল করতে)

```bash
flutter build apk --release
```

APK পাবেন এখানে:
```
build/app/outputs/flutter-apk/app-release.apk
```

এই APK ফাইলটি:
- মোবাইলে পাঠান (WhatsApp/Telegram)
- ইনস্টল করুন
- ১ লাখ মানুষকে শেয়ার করুন! 🚀

---

## ✅ ধাপ ৪: Play Store-এ দিন (ঐচ্ছিক)

```bash
flutter build appbundle --release
```

- Google Play Console: https://play.google.com/console
- একবার $25 ফি দিতে হবে
- তারপর আনলিমিটেড অ্যাপ দেওয়া যাবে

---

## 📁 প্রজেক্ট স্ট্রাকচার

```
chat_app/
├── lib/
│   └── main.dart          ← Flutter কোড
├── assets/
│   └── web/
│       └── index.html     ← অ্যাপের UI
├── android/               ← Android সেটিংস
└── pubspec.yaml           ← Dependencies
```

---

## 🔧 সমস্যা হলে

```bash
flutter doctor -v          # সমস্যা খুঁজে বের করুন
flutter clean              # ক্যাশ মুছুন
flutter pub get            # আবার চেষ্টা করুন
```

---

## 💡 পরবর্তী ধাপ (আরও উন্নত করতে)

| ফিচার | টুল | খরচ |
|-------|-----|-----|
| রিয়েল চ্যাট | Firebase Firestore | ফ্রি |
| লগিন | Firebase Auth | ফ্রি |
| নোটিফিকেশন | Firebase FCM | ফ্রি |
| ছবি স্টোরেজ | Firebase Storage | ফ্রি (৫GB) |

সব ফ্রি! 🎉
